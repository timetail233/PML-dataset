import math

import numpy as np
import torch
import torch.nn as nn


class ECA(nn.Module):
    def __init__(self, channels, gamma=2, b=1):
        super(ECA, self).__init__()
        k = int(abs((np.log2(channels) + b) / gamma))
        k = k if k % 2 else k + 1
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.conv = nn.Conv1d(1, 1, kernel_size=k, padding=k // 2, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        y = self.avg_pool(x)  # [B,C,1,1]
        y = self.conv(y.squeeze(-1).transpose(-1, -2))  # [B,1,C]
        y = self.sigmoid(y.transpose(-1, -2).unsqueeze(-1))  # [B,C,1,1]
        return x * y.expand_as(x)


# 空间注意力模块
class SpatialATT(nn.Module):
    def __init__(self):
        super(SpatialATT, self).__init__()
        self.conv1 = nn.Conv2d(in_channels=2, out_channels=1, kernel_size=1, stride=1, padding=0)
        self.conv2 = nn.Conv2d(in_channels=2, out_channels=1, kernel_size=3, stride=1, padding=1)
        self.conv3 = nn.Conv2d(in_channels=2, out_channels=1, kernel_size=5, stride=1, padding=2)

        self.conv4 = nn.Conv2d(in_channels=3, out_channels=1, kernel_size=1, stride=1, padding=0)
        # self.act=SiLU()
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        avgout = torch.mean(x, dim=1, keepdim=True)
        maxout, _ = torch.max(x, dim=1, keepdim=True)
        out = torch.cat([avgout, maxout], dim=1)
        out1 = self.conv1(out)
        out2 = self.conv2(out)
        out3 = self.conv3(out)
        out = torch.cat([out1, out2, out3], dim=1)
        out = self.conv4(out)
        out = self.sigmoid(out)

        return out * x


class AttM(nn.Module):
    def __init__(self, in_channels, fc_num=8):
        super(AttM, self).__init__()
        self.spATT = SpatialATT()

        self.first_layer = nn.Sequential(
            nn.Conv2d(in_channels, in_channels * 2, kernel_size=3, stride=2, padding=1),  # [B,32,D/2,H/2,W/2]
            nn.BatchNorm2d(in_channels * 2),
            nn.LeakyReLU())

        self.fc_mu = nn.Sequential(
            nn.Linear(in_channels * 2 * fc_num * fc_num, in_channels))

        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.max_pool = nn.AdaptiveMaxPool2d(1)
        # 共享权重的MLP（使用1x1卷积替代全连接层）
        # t = int(abs((math.log2(in_channels) + 1) / 2))
        # k = t if t % 2 else t + 1  # k必须为奇数
        self.mlp = nn.Sequential(
            nn.Conv1d(
                in_channels=1,
                out_channels=1,
                kernel_size=5,
                padding=(5 - 1) // 2,  # 保持输出长度不变
                bias=False
            ),
            nn.ReLU(),
        )
        self.sigmoid = nn.Sigmoid()

    def forward(self, x1, x2):
        x = torch.cat([x1, x2], dim=1)
        x = self.spATT(x)
        a1 = self.avg_pool(x)
        a2 = self.max_pool(x)
        a12 = a1+a2
        a12 = a12.squeeze(-1).transpose(1, 2)
        # a1 = a1.squeeze(-1).transpose(1, 2)
        # a2 = a2.squeeze(-1).transpose(1, 2)
        # avg_out = self.mlp(a1)
        # max_out = self.mlp(a2)
        # channel_weights1 = self.sigmoid(avg_out + max_out)
        channel_weights1 = self.sigmoid(self.mlp(a12))
        channel_weights1 = channel_weights1.squeeze(1)
        a3 = self.first_layer(x)
        # print(a3.shape)
        a3 = torch.flatten(a3, start_dim=1)
        a3 = self.fc_mu(a3)
        channel_weights2 = self.sigmoid(a3)

        # print(channel_weights1.shape)
        # print(channel_weights2.shape)

        channel_weights = channel_weights1 * channel_weights2
        split_sizes = channel_weights.shape[1] // 2

        y1, y2 = torch.split(channel_weights, split_sizes, dim=1)

        y1 = y1.unsqueeze(-1).unsqueeze(-1)
        y2 = y2.unsqueeze(-1).unsqueeze(-1)

        return y1, y2


if __name__ == '__main__':
    model = AttM(in_channels=256, fc_num=2)
    # 方法2：随机初始化（更接近真实数据）
    input1 = torch.rand(2, 128, 4, 4)  # 模拟批量2的特征图
    input2 = torch.rand(2, 128, 4, 4)  # 模拟批量2的特征图
    out1, out2 = model(input1, input2)
    spmodel = SpatialATT()
    out3 = spmodel(input1)
    print(out2.shape)
