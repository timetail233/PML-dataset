import torch
import torch.nn as nn
import torch.nn.functional as F


class SpatialATT(nn.Module):
    def __init__(self):
        super(SpatialATT, self).__init__()
        self.conv1 = nn.Conv2d(in_channels=2, out_channels=1, kernel_size=1, stride=1, padding=0)
        self.conv2 = nn.Conv2d(in_channels=2, out_channels=1, kernel_size=3, stride=1, padding=1)
        self.conv3 = nn.Conv2d(in_channels=2, out_channels=1, kernel_size=5, stride=1, padding=2)

        self.conv4 = nn.Conv2d(in_channels=3, out_channels=1, kernel_size=1, stride=1, padding=0)
        # self.act=SiLU()
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        avgout = torch.mean(x, dim=1, keepdim=True)
        maxout, _ = torch.max(x, dim=1, keepdim=True)
        out = torch.cat([avgout, maxout], dim=1)
        out1 = self.conv1(out)
        out2 = self.conv2(out)
        out3 = self.conv3(out)
        out = torch.cat([out1, out2, out3], dim=1)
        out = self.conv4(out)
        out = self.sigmoid(out)

        return out * x


class AttM_withoutSplit(nn.Module):
    def __init__(self, in_channels, fc_num=8):
        super(AttM_withoutSplit, self).__init__()
        self.spATT = SpatialATT()

        self.first_layer = nn.Sequential(
            nn.Conv2d(in_channels, in_channels * 2, kernel_size=3, stride=2, padding=1),  # [B,32,D/2,H/2,W/2]
            nn.BatchNorm2d(in_channels * 2),
            nn.LeakyReLU())

        self.fc_mu = nn.Sequential(
            nn.Linear(in_channels * 2 * fc_num * fc_num, in_channels))

        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.max_pool = nn.AdaptiveMaxPool2d(1)
        # 共享权重的MLP（使用1x1卷积替代全连接层）
        # t = int(abs((math.log2(in_channels) + 1) / 2))
        # k = t if t % 2 else t + 1  # k必须为奇数
        self.mlp = nn.Sequential(
            nn.Conv1d(
                in_channels=1,
                out_channels=1,
                kernel_size=5,
                padding=(5 - 1) // 2,  # 保持输出长度不变
                bias=False
            ),
            nn.ReLU(),
        )
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        x = self.spATT(x)
        a1 = self.avg_pool(x)
        a2 = self.max_pool(x)
        a12 = a1 + a2
        a12 = a12.squeeze(-1).transpose(1, 2)
        # a1 = a1.squeeze(-1).transpose(1, 2)
        # a2 = a2.squeeze(-1).transpose(1, 2)
        # avg_out = self.mlp(a1)
        # max_out = self.mlp(a2)
        # channel_weights1 = self.sigmoid(avg_out + max_out)
        channel_weights1 = self.sigmoid(self.mlp(a12))
        channel_weights1 = channel_weights1.squeeze(1)
        a3 = self.first_layer(x)
        # print(a3.shape)
        a3 = torch.flatten(a3, start_dim=1)
        a3 = self.fc_mu(a3)
        channel_weights2 = self.sigmoid(a3)

        # print(channel_weights1.shape)
        # print(channel_weights2.shape)

        channel_weights = channel_weights1 * channel_weights2
        # split_sizes = channel_weights.shape[1] // 2
        channel_weights = channel_weights.unsqueeze(-1).unsqueeze(-1)
        return channel_weights


class PGBranch(nn.Module):
    def __init__(self, in_channels=1, latent_dim=256):
        super(PGBranch, self).__init__()
        self.hid = 256 * 2 * 4 * 4
        # Encoder
        self.encoder = nn.Sequential(
            nn.Conv3d(in_channels, 32, kernel_size=3, stride=2, padding=1),  # [B,32,D/2,H/2,W/2]
            nn.BatchNorm3d(32),
            nn.LeakyReLU(),
            nn.Conv3d(32, 64, kernel_size=3, stride=2, padding=1),  # [B,64,D/4,H/4,W/4]
            nn.BatchNorm3d(64),
            nn.LeakyReLU(),
            nn.Conv3d(64, 128, kernel_size=3, stride=2, padding=1),  # [B,128,D/8,H/8,W/8]
            nn.BatchNorm3d(128),
            nn.LeakyReLU(),
            nn.Conv3d(128, 256, kernel_size=3, stride=2, padding=1),  # [B,256,D/16,H/16,W/16]
            nn.BatchNorm3d(256),
            nn.LeakyReLU(),
            # nn.Conv3d(256, 512, kernel_size=3, stride=2, padding=1),  # [B,512,D/32,H/32,W/32]
            # nn.BatchNorm3d(512),
            # nn.ReLU()
        )
        self.ATT1 = AttM_withoutSplit(in_channels=256, fc_num=2)

    def forward(self, x):
        x = self.encoder(x)
        x = torch.mean(x, dim=2)
        x = self.ATT1(x)
        return x


if __name__ == '__main__':
    model = PGBranch(in_channels=1)
    # 方法2：随机初始化（更接近真实数据）
    input1 = torch.rand(2, 1, 32, 64, 64)  # 模拟批量2的特征图
    out1 = model(input1)
    print(out1.shape)
