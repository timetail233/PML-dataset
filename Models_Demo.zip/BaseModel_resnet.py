import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
import torch.nn as nn
import torch.nn.functional as F

from NewModels.AttModule import AttM
from Utils_box.dataloader_GAN import NpyDataset, NpyDataset_noZ


class basic_block(nn.Module):
    '''定义了带实线部分的残差块'''

    def __init__(self, in_channels):
        super(basic_block, self).__init__()
        self.conv1 = nn.Conv2d(in_channels, in_channels, kernel_size=3, stride=1, padding=1)
        self.conv2 = nn.Conv2d(in_channels, in_channels, kernel_size=3, stride=1, padding=1)

    def forward(self, x):
        y = F.relu(self.conv1(x))
        y = self.conv2(y)
        return F.relu(x + y)


class basic_block2(nn.Module):
    '''定义了带虚线部分的残差块'''

    def __init__(self, in_channels, out_channels):
        super(basic_block2, self).__init__()
        self.conv1 = nn.Conv2d(in_channels, out_channels, kernel_size=1, stride=2)
        self.conv2 = nn.Conv2d(in_channels, out_channels, kernel_size=3, stride=2, padding=1)
        self.conv3 = nn.Conv2d(out_channels, out_channels, kernel_size=3, stride=1, padding=1)

    def forward(self, x):
        z = self.conv1(x)
        y = F.relu(self.conv2(x))
        y = self.conv3(y)
        return F.relu(y + z)


class basic_block_resnet(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(basic_block_resnet, self).__init__()
        self.layer1 = basic_block(in_channels)
        self.layer2 = basic_block2(in_channels, out_channels)

    def forward(self, x):
        x = self.layer1(x)
        x = self.layer2(x)
        return x


class basic_block_resnet_2X(nn.Module):
    def __init__(self, in_channels, out_channels, out_channels2):
        super(basic_block_resnet_2X, self).__init__()
        self.layer1 = basic_block_resnet(in_channels, out_channels)
        self.layer2 = basic_block_resnet(out_channels, out_channels2)

    def forward(self, x):
        x = self.layer1(x)
        x = self.layer2(x)
        return x


class first_layer(nn.Module):
    def __init__(self, in_channels=3, out_channels=16):
        super(first_layer, self).__init__()
        self.layer = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, kernel_size=3, stride=1, padding=1),  # [B,32,D/2,H/2,W/2]
            nn.BatchNorm2d(16),
            nn.LeakyReLU())

    def forward(self, x):
        x = self.layer(x)
        return x


class BaseModel(nn.Module):
    def __init__(self):
        # 共享的初始卷积层
        super(BaseModel, self).__init__()
        self.first_layer_ot1 = first_layer()
        self.first_layer_ot2 = first_layer()
        self.first_layer_mpm1 = first_layer()
        self.first_layer_mpm2 = first_layer()
        self.first_layer_vis = first_layer()

        self.restblock1_1 = basic_block_resnet_2X(in_channels=32, out_channels=64, out_channels2=128)
        self.restblock2_1 = basic_block_resnet_2X(in_channels=32, out_channels=64, out_channels2=128)
        self.restblock3_1 = basic_block_resnet_2X(in_channels=16, out_channels=64, out_channels2=128)

        self.ATT1 = AttM(in_channels=256)
        self.ATT2 = AttM(in_channels=256)
        self.ATT3 = AttM(in_channels=256)

        self.restblock1_2 = basic_block_resnet_2X(in_channels=256, out_channels=256, out_channels2=512)
        self.restblock2_2 = basic_block_resnet_2X(in_channels=256, out_channels=256, out_channels2=512)
        self.restblock3_2 = basic_block_resnet_2X(in_channels=256, out_channels=256, out_channels2=512)

        self.restblockfinal = basic_block_resnet_2X(in_channels=512 * 3, out_channels=1024, out_channels2=1024)

        self.fc_mu = nn.Sequential(
            nn.Linear(1024, 512),
            nn.Linear(512, 128))

    def forward(self, x):
        ot1 = x[:, 0, :, :]
        ot2 = x[:, 1, :, :]
        mpm1 = x[:, 2, :, :]
        mpm2 = x[:, 3, :, :]
        vis = x[:, 4, :, :]
        ot1 = self.first_layer_ot1(ot1)
        ot2 = self.first_layer_ot2(ot2)
        ot = torch.cat([ot1, ot2], dim=1)
        ot = self.restblock1_1(ot)

        mpm1 = self.first_layer_mpm1(mpm1)
        mpm2 = self.first_layer_mpm2(mpm2)
        mpm = torch.cat([mpm1, mpm2], dim=1)
        mpm = self.restblock2_1(mpm)

        vis = self.first_layer_vis(vis)
        vis = self.restblock3_1(vis)

        at1_1, at1_2 = self.ATT1(ot, mpm)
        at2_1, at2_2 = self.ATT2(mpm, vis)
        at3_1, at3_2 = self.ATT3(vis, ot)

        ot = torch.cat([ot * at1_1, ot * at3_2], dim=1)
        mpm = torch.cat([mpm * at1_2, mpm * at2_1], dim=1)
        vis = torch.cat([vis * at2_2, vis * at3_1], dim=1)

        ot = self.restblock1_2(ot)
        mpm = self.restblock2_2(mpm)
        vis = self.restblock3_2(vis)

        out = torch.cat([ot, mpm, vis], dim=1)
        out = self.restblockfinal(out)
        out = self.fc_mu(torch.flatten(out, start_dim=1))

        return out


if __name__ == '__main__':
    model = BaseModel()
    # 方法2：随机初始化（更接近真实数据）
    input = torch.rand(2, 5, 3, 64, 64)  # 模拟批量2的特征图
    out = model(input)
    print(out.shape)
