import torch
import torch.nn as nn
import torch.nn.functional as F


class KVProjection(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(KVProjection, self).__init__()
        # 通常使用1x1卷积生成Q、K、V
        # self.q_conv = nn.Conv2d(in_channels, out_channels, kernel_size=3,padding=1)
        self.k_conv = nn.Conv2d(in_channels, out_channels, kernel_size=3, padding=1)
        self.v_conv = nn.Conv2d(in_channels, out_channels, kernel_size=3, padding=1)

    def forward(self, x):
        # Q = self.q_conv(x)  # [B, C, H, W]
        K = self.k_conv(x)  # [B, C, H, W]
        V = self.v_conv(x)  # [B, C, H, W]
        return K, V


class Qrojection(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(Qrojection, self).__init__()
        # 通常使用1x1卷积生成Q、K、V
        self.q_conv = nn.Conv2d(in_channels, out_channels, kernel_size=3, padding=1)

    def forward(self, x1, x2, x3):
        x = torch.cat([x1, x2, x3], dim=1)
        Q = self.q_conv(x)  # [B, C, H, W]

        return Q


def compute_attention(Q, K):
    B, C, H, W = K.shape
    K = K.view(B, -1, C).transpose(1, 2)  # [B, C, H*W]
    attn = torch.bmm(Q, K)  # [B, H*W, H*W]
    attn = torch.softmax(attn, dim=-1)
    return attn


def compute_features(At, V, x):
    B, C, H, W = V.shape
    V = V.view(B, -1, C)  # [B, H*W, C]
    out = torch.bmm(At, V)
    out = out.transpose(1, 2)
    out = out.view(B, C, H, W)

    return out + x


class PIDFA_part1(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(PIDFA_part1, self).__init__()
        # 通常使用1x1卷积生成Q、K、V
        self.kv1 = KVProjection(in_channels=in_channels, out_channels=out_channels)  # [B, C, H, W]
        self.kv2 = KVProjection(in_channels=in_channels, out_channels=out_channels)  # [B, C, H, W]
        self.kv3 = KVProjection(in_channels=in_channels, out_channels=out_channels)  # [B, C, H, W]
        self.q = Qrojection(in_channels=in_channels * 3, out_channels=out_channels)  # [B, C, H, W]

    def forward(self, x1, x2, x3):
        k1, v1 = self.kv1(x1)
        k2, v2 = self.kv2(x2)
        k3, v3 = self.kv3(x3)
        q = self.q(x1, x2, x3)  # [B, C, H, W]
        B, C, H, W = q.shape
        q = q.view(B, -1, C)  # [B, H*W, C]
        # print(q.shape)
        attn1 = compute_attention(q, k1)  # [B, H*W, H*W]
        attn2 = compute_attention(q, k2)  # [B, H*W, H*W]
        attn3 = compute_attention(q, k3)  # [B, H*W, H*W]

        f1 = compute_features(attn1, v1, x1)
        f2 = compute_features(attn2, v2, x2)
        f3 = compute_features(attn3, v3, x3)

        return f1, f2, f3


class basic_block(nn.Module):
    '''定义了带实线部分的残差块'''

    def __init__(self, in_channels):
        super(basic_block, self).__init__()
        self.conv1 = nn.Conv2d(in_channels, in_channels, kernel_size=3, stride=1, padding=1)
        self.conv2 = nn.Conv2d(in_channels, in_channels, kernel_size=3, stride=1, padding=1)

    def forward(self, x):
        y = F.relu(self.conv1(x))
        y = self.conv2(y)
        return F.relu(x + y)


class basic_block2(nn.Module):
    '''定义了带虚线部分的残差块'''

    def __init__(self, in_channels, out_channels):
        super(basic_block2, self).__init__()
        self.conv1 = nn.Conv2d(in_channels, out_channels, kernel_size=1, stride=2)
        self.conv2 = nn.Conv2d(in_channels, out_channels, kernel_size=3, stride=2, padding=1)
        self.conv3 = nn.Conv2d(out_channels, out_channels, kernel_size=3, stride=1, padding=1)

    def forward(self, x):
        z = self.conv1(x)
        y = F.relu(self.conv2(x))
        y = self.conv3(y)
        return F.relu(y + z)


class basic_block_resnet(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(basic_block_resnet, self).__init__()
        self.layer1 = basic_block(in_channels)
        self.layer2 = basic_block2(in_channels, out_channels)

    def forward(self, x):
        x = self.layer1(x)
        x = self.layer2(x)
        return x


class PIDFA_part2(nn.Module):
    def __init__(self, in_channels, out_channels, out_channels2=1024):
        super(PIDFA_part2, self).__init__()
        self.layer1 = basic_block_resnet(in_channels, out_channels)
        self.layer2 = basic_block_resnet(in_channels, out_channels)
        self.layer3 = basic_block_resnet(out_channels, out_channels2)

    def forward(self, x1, x2, x3):
        x1_s = self.layer1(x1)
        x2_s = self.layer1(x2)
        x3_s = self.layer1(x3)
        x_sum = x1_s + x2_s + x3_s
        x1_f = self.layer2(x1)
        x2_f = self.layer2(x2)
        x3_f = self.layer2(x3)
        x_f = torch.abs(x1_f - x2_f) + torch.abs(x2_f - x3_f) + torch.abs(x3_f - x1_f)
        x_all = x_sum + x_f
        x_all = self.layer3(x_all)

        return x_all


class PIDFA(nn.Module):
    def __init__(self, in_channels=256, out_channels=256, out_channels2=1024):
        super(PIDFA, self).__init__()

        self.part1 = PIDFA_part1(in_channels, out_channels)
        self.part2 = PIDFA_part2(in_channels, out_channels, out_channels2)

    def forward(self, x1, x2, x3):
        f1, f2, f3 = self.part1(x1, x2, x3)
        out = self.part2(f1, f2, f3)

        return out


if __name__ == '__main__':
    model = PIDFA()
    # 方法2：随机初始化（更接近真实数据）
    input1 = torch.rand(2, 256, 16, 16)  # 模拟批量1的特征图
    input2 = torch.rand(2, 256, 16, 16)  # 模拟批量2的特征图
    input3 = torch.rand(2, 256, 16, 16)  # 模拟批量3的特征图
    q = model(input1, input2, input3)
    print(q.shape)
